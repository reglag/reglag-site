"""
Utility functions for the regulatory notices project.

This module provides text summarisation and helper functions to
filter and group regulatory updates.  It is separate from the Flask
application so it can be reused in both the dynamic app and the
static site builder without importing Flask.
"""

from __future__ import annotations

import re
import string
from collections import Counter
from datetime import datetime
from typing import List, Dict
from zoneinfo import ZoneInfo

__all__ = [
    "summarise_text",
    "filter_updates_by_date",
    "group_updates_by_date",
    "get_current_date_iso",
]


def summarise_text(text: str, sentences: int = 2) -> str:
    """Generate a summary of the input text.

    This function first attempts to call the OpenAI ChatGPT API (using the
    ``gpt-4o-mini`` model) to create a high‑quality summary.  If the API is
    unavailable—for example, because the ``openai`` package is not installed,
    no API key is configured, or the network request fails—it falls back to
    a simple extractive summariser implemented locally.  The extractive
    summariser splits the text into sentences, computes word frequencies
    (ignoring common stop words and punctuation), scores each sentence by
    summing the frequencies of its words and returns the top ``sentences``
    sentences in their original order.  If the input text is very short, the
    original text is returned unchanged.

    Args:
        text: The input text to summarise.
        sentences: Desired number of sentences in the summary.

    Returns:
        A string containing the summary.
    """
    # Handle empty input
    if not text:
        return ""

    # First try to summarise with the OpenAI API.  This code attempts to
    # import the ``openai`` library and retrieve the API key from the
    # ``OPENAI_API_KEY`` environment variable.  If any step fails, it
    # gracefully falls back to the extractive method defined below.
    try:
        import os
        import openai  # type: ignore
        api_key = os.getenv("OPENAI_API_KEY")
        # Only attempt the API call if a key is present
        if api_key:
            summary_text: str | None = None
            try:
                # New client interface (openai >= 1.0)
                client = openai.OpenAI(api_key=api_key)
                response = client.chat.completions.create(
                    model="gpt-4o-mini",
                    messages=[
                        {
                            "role": "system",
                            "content": (
                                "You are a helpful assistant that summarizes regulatory notices."
                            ),
                        },
                        {
                            "role": "user",
                            "content": (
                                f"Summarize the following text in {sentences} sentences:\n\n{text}"
                            ),
                        },
                    ],
                    max_tokens=400,
                    temperature=0.3,
                )
                summary_text = response.choices[0].message.content.strip()
                # Print debug message indicating success
                print(
                    "[DEBUG] Used OpenAI API for summarization via new client interface."
                )
            except AttributeError:
                # Legacy interface (openai < 1.0)
                openai.api_key = api_key  # type: ignore
                response = openai.ChatCompletion.create(
                    model="gpt-4o-mini",
                    messages=[
                        {
                            "role": "system",
                            "content": (
                                "You are a helpful assistant that summarizes regulatory notices."
                            ),
                        },
                        {
                            "role": "user",
                            "content": (
                                f"Summarize the following text in {sentences} sentences:\n\n{text}"
                            ),
                        },
                    ],
                    max_tokens=400,
                    temperature=0.3,
                )
                summary_text = response.choices[0].message["content"].strip()
                print(
                    "[DEBUG] Used OpenAI API for summarization via legacy interface."
                )
            # If we successfully obtained a summary, return it
            if summary_text:
                return summary_text
    except Exception as e:
        # Log the exception so we know why the API call failed
        print(f"[DEBUG] Falling back to extractive summarization due to error: {e}")
        # The function will fall back to the extractive approach below.
        pass

    # ---------------------------------------------------------------------
    # Fallback: simple extractive summariser.  It computes word frequencies
    # and selects the top scoring sentences.  If the text is short (less
    # than ``sentences`` sentences or fewer than ~30 words), return as is.
    sentence_delims = re.compile(r'(?:[.!?]+)\s+')
    raw_sentences = sentence_delims.split(text.strip())
    if len(raw_sentences) <= sentences or len(text.split()) < 30:
        return text.strip()
    stop_words = {
        'the', 'and', 'of', 'to', 'in', 'a', 'is', 'it', 'for', 'on', 'that',
        'with', 'as', 'be', 'are', 'this', 'an', 'by', 'or', 'from',
        'at', 'which', 'but', 'not', 'they', 'their', 'its', 'has', 'have',
        'may', 'these', 'will', 'can', 'had', 'been', 'such', 'into', 'about',
        'other', 'more', 'also', 'if', 'all', 'one', 'each', 'any'
    }
    translator = str.maketrans('', '', string.punctuation)
    words = [w.lower().translate(translator) for w in text.split()]
    freq = Counter()
    for w in words:
        if w and w not in stop_words and not w.isdigit():
            freq[w] += 1
    sentence_scores = []
    for i, sent in enumerate(raw_sentences):
        sent_words = [w.lower().translate(translator) for w in sent.split()]
        score = sum(freq.get(w, 0) for w in sent_words if w and w not in stop_words)
        sentence_scores.append((i, score, sent.strip()))
    top_sentences = sorted(sentence_scores, key=lambda x: x[1], reverse=True)[:sentences]
    selected = sorted(top_sentences, key=lambda x: x[0])
    summary = ' '.join(s[2] for s in selected)
    return summary


def filter_updates_by_date(updates: List[Dict[str, str]], date_str: str) -> List[Dict[str, str]]:
    """Filter updates for a given ISO date string."""
    return [u for u in updates if u.get("date") == date_str]


def group_updates_by_date(updates: List[Dict[str, str]]) -> Dict[str, List[Dict[str, str]]]:
    """Group updates by their publication date."""
    grouped: Dict[str, List[Dict[str, str]]] = {}
    for u in updates:
        d = u.get("date")
        if d:
            grouped.setdefault(d, []).append(u)
    return grouped


def get_current_date_iso() -> str:
    """Return today's date in America/New_York timezone as an ISO string."""
    tz = ZoneInfo("America/New_York")
    return datetime.now(tz=tz).date().isoformat()