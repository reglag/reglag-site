"""
Utility script to build a static version of the regulatory notice website.

This script reads the JSON dataset of regulatory updates, summarises
the content using a simple extractive summarisation algorithm and
generates static HTML files (index.html and all.html) along with a
stylesheet.  The resulting `site/` directory contains everything
needed to view the website offline in a browser.

Because the environment does not provide Flask, this static build
approach allows you to preview the site's look and feel.  To update
the site with new notices, modify `data/updates.json` and rerun this
script.

Usage:
    python3 build_site.py

"""

import json
import os
from datetime import datetime
from typing import List, Dict

from utils import summarise_text, filter_updates_by_date, group_updates_by_date, get_current_date_iso
from federal_register_api import fetch_recent_updates


def load_updates(path: str) -> List[Dict[str, str]]:
    """Load updates from a JSON file."""
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def render_index(date: str, summary: str, entries: List[Dict[str, str]]) -> str:
    """Render the index page HTML."""
    # Basic HTML structure similar to the Flask template
    entry_html = []
    for e in entries:
        entry_html.append(f"""
        <article class="entry">
          <h3 class="entry-title"><a href="{e['link']}" target="_blank" rel="noopener">{e['title']}</a></h3>
          <p class="entry-meta"><strong>Source:</strong> {e['source']}</p>
          <p class="entry-summary">{e['summary']}</p>
        </article>
        """)
    entries_block = "\n".join(entry_html)

    return f"""<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>RegLag Daily Summary</title>
    <link rel="stylesheet" href="style.css" />
  </head>
    <body>
    <header>
      <!-- Make the site title link back to the home page -->
      <h1><a href="index.html">RegLag</a></h1>
      <p class="date">Daily Summary for {date}</p>
      <!-- Site descriptor tagline -->
      <p class="tagline">
        RegLag provides daily, analyst-grade synthesis of U.S. financial regulatory developments, focused on materiality, context,
        and forward-looking implications for legal, compliance, and investment professionals.
      </p>
      <!-- Disclaimer -->
      <p class="disclaimer">
        RegLag provides general regulatory intelligence and analysis for informational purposes only. It does not constitute legal,
        tax, or investment advice or a recommendation to engage in any transaction or strategy. Readers should consult their own
        advisors regarding specific circumstances.
      </p>
    </header>

    <main>
      <section class="daily-summary">
        <h2>Overview</h2>
        <p>{summary}</p>
      </section>
      <section class="entries">
        <h2>Detailed Updates</h2>
        {entries_block}
      </section>
      <nav class="navigation">
        <a href="all.html">View All Updates</a>
      </nav>
    </main>
    <footer>
      <p>Data compiled from public sources such as the Federal Register and FINRA.</p>
    </footer>
  </body>
</html>"""


def render_all(grouped: Dict[str, List[Dict[str, str]]]) -> str:
    """Render the all updates page HTML.

    This function summarises each update's content using the same summarisation routine
    used on the homepage.  Summaries are limited to two sentences to provide
    concise descriptions of each notice.  The site title links back to the
    home page (index.html) for easy navigation.
    """
    day_sections: List[str] = []
    # Sort dates descending
    for d in sorted(grouped.keys(), reverse=True):
        entries_html: List[str] = []
        for e in grouped[d]:
            # Summarise each entry's content to 2 sentences
            try:
                entry_summary = summarise_text(e["content"], sentences=2)
            except Exception:
                # On failure, fall back to the full content
                entry_summary = e.get("content", "")
            entries_html.append(f"""
        <article class="entry">
          <h3 class="entry-title"><a href="{e['link']}" target="_blank" rel="noopener">{e['title']}</a></h3>
          <p class="entry-meta"><strong>Source:</strong> {e['source']}</p>
          <p class="entry-summary">{entry_summary}</p>
        </article>
            """)
        entries_block = "\n".join(entries_html)
        day_sections.append(f"""
      <section class="day-group">
        <h2>{d}</h2>
        {entries_block}
      </section>
        """)
    all_sections = "\n".join(day_sections)

    return f"""<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>RegLag All Updates</title>
    <link rel="stylesheet" href="style.css" />
  </head>
  <body>
    <header>
      <!-- Title links back to the daily summary (index page) -->
      <h1><a href="index.html">RegLag</a></h1>
      <p class="date">All Updates</p>
      <nav class="navigation">
        <a href="index.html">Back to Summary</a>
      </nav>
      <!-- Site descriptor tagline -->
      <p class="tagline">
        RegLag provides daily, analyst-grade synthesis of U.S. financial regulatory developments, focused on materiality, context,
        and forward-looking implications for legal, compliance, and investment professionals.
      </p>
      <!-- Disclaimer -->
      <p class="disclaimer">
        RegLag provides general regulatory intelligence and analysis for informational purposes only. It does not constitute legal,
        tax, or investment advice or a recommendation to engage in any transaction or strategy. Readers should consult their own
        advisors regarding specific circumstances.
      </p>
    </header>
    <main>
      {all_sections}
    </main>
    <footer>
      <p>Data compiled from public sources such as the Federal Register and FINRA.</p>
    </footer>
  </body>
</html>"""


def build_site():
    """Main entry point to build the static site."""
    data_path = os.path.join(os.path.dirname(__file__), "data", "updates.json")
    updates = load_updates(data_path)

    # -------------------------------------------------------------------------
    # Fetch additional updates from the Federal Register API.  This call pulls
    # the most recent documents for selected agencies and adds them to the
    # dataset.  If network access is unavailable, a warning will be printed and
    # no new updates will be added.
    #
    # Agencies to include when fetching updates from the Federal Register API.
    #
    # The list below contains the slug identifiers used by FederalRegister.gov
    # for each regulatory agency that this project tracks.  We include the
    # traditional banking regulators (FDIC, Federal Reserve and SEC), as well
    # as other financial regulators of interest to compliance professionals such
    # as the Office of Foreign Assets Control (OFAC), the Office of the
    # Comptroller of the Currency (OCC), the Commodity Futures Trading
    # Commission (CFTC) and the Financial Crimes Enforcement Network (FinCEN).
    #
    # The slugs correspond to the lowercase hyphen‑separated agency names on
    # FederalRegister.gov.  When network access is unavailable the API call
    # silently fails and no updates are added.
    agency_slugs = [
        'federal-deposit-insurance-corporation',      # FDIC
        'federal-reserve-system',                    # Federal Reserve
        'securities-and-exchange-commission',        # SEC
        'foreign-assets-control-office',             # OFAC
        'comptroller-of-the-currency',               # OCC
        'commodity-futures-trading-commission',      # CFTC
        'financial-crimes-enforcement-network',       # FinCEN
        'department-of-commerce'                     # Department of Commerce (e.g., BIS, ITA, NIST)
    ]
    api_updates = fetch_recent_updates(agency_slugs, per_page=3)
    if api_updates:
        # Deduplicate based on (title, date) to avoid adding duplicates if the
        # update already exists in the local dataset.  Lowercase titles for
        # comparison.
        existing_keys = {(u["title"].lower(), u["date"]) for u in updates}
        for upd in api_updates:
            key = (upd.get("title", "").lower(), upd.get("date"))
            if key not in existing_keys:
                updates.append(upd)
                existing_keys.add(key)
    if not updates:
        raise RuntimeError("No updates found; ensure updates.json contains data")

    # Determine today's date in the user's timezone
    today_iso = get_current_date_iso()
    todays_updates = filter_updates_by_date(updates, today_iso)
    if not todays_updates:
        # Use the most recent date in the dataset
        latest_date = max(u["date"] for u in updates)
        display_date = latest_date
        todays_updates = filter_updates_by_date(updates, latest_date)
    else:
        display_date = today_iso

    # Create summary for index page
    combined_text = "\n".join(u["content"] for u in todays_updates)
    daily_summary = summarise_text(combined_text, sentences=3)
    entries_summaries = []
    for u in todays_updates:
        entries_summaries.append({
            "date": u["date"],
            "source": u["source"],
            "title": u["title"],
            "link": u["link"],
            "summary": summarise_text(u["content"], sentences=2)
        })

    # Group all updates by date for the all page
    grouped = group_updates_by_date(updates)

    # Prepare output directory
    site_dir = os.path.join(os.path.dirname(__file__), "site")
    os.makedirs(site_dir, exist_ok=True)

    # Write index.html and all.html
    index_html = render_index(display_date, daily_summary, entries_summaries)
    with open(os.path.join(site_dir, "index.html"), "w", encoding="utf-8") as f:
        f.write(index_html)
    all_html = render_all(grouped)
    with open(os.path.join(site_dir, "all.html"), "w", encoding="utf-8") as f:
        f.write(all_html)

    # Copy stylesheet
    static_css = os.path.join(os.path.dirname(__file__), "static", "style.css")
    dest_css = os.path.join(site_dir, "style.css")
    with open(static_css, "r", encoding="utf-8") as src, open(dest_css, "w", encoding="utf-8") as dst:
        dst.write(src.read())

    print(f"Site built in {site_dir}")


if __name__ == "__main__":
    build_site()