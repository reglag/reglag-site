"""
Utilities for fetching recent documents from the Federal Register API.

This module defines helper functions to query the Federal Register API for
recent documents related to specified agencies.  It uses Python’s built-in
`urllib` modules to avoid external dependencies.  Each document returned
contains a title, abstract, publication date and link.  You can integrate
these helpers into the site’s build process to automatically populate new
entries from the Federal Register when regenerating the site.

Note: Network access is required for these functions to work.  When run in
environments without outbound internet connectivity, the calls will fail.
"""

from __future__ import annotations

import json
import urllib.parse
import urllib.request
from typing import List, Dict


def fetch_documents_for_agency(agency_slug: str, per_page: int = 5) -> List[Dict[str, str]]:
    """Fetch recent documents from the Federal Register API for a specific agency.

    Args:
        agency_slug: The slug of the agency (e.g., 'federal-reserve-system').
        per_page: Number of documents to retrieve (default 5).

    Returns:
        A list of result dictionaries from the API.  Each dictionary includes
        keys like 'title', 'abstract', 'publication_date', 'html_url' and
        'agencies'.
    """
    # Build query parameters.  Using doseq=True ensures that list values are
    # encoded properly (e.g., conditions%5Bagencies%5D%5B%5D=value).
    params = {
        'conditions[agencies][]': agency_slug,
        'per_page': per_page,
        'order': 'newest',  # fetch most recent documents first
    }
    query = urllib.parse.urlencode(params, doseq=True)
    url = f'https://www.federalregister.gov/api/v1/documents.json?{query}'
    # Provide a user agent to avoid potential blocking by the server
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    with urllib.request.urlopen(req) as response:
        data = json.loads(response.read().decode())
        return data.get('results', [])


def transform_results_to_updates(results: List[Dict[str, str]]) -> List[Dict[str, str]]:
    """Convert API result dictionaries into update entries for the site.

    Each result is mapped to a dictionary with keys expected by the site’s
    dataset: date, source, title, link and content.  If a result lacks an
    abstract, it will be skipped since there is nothing to summarise.

    Args:
        results: List of raw result dictionaries from the API.

    Returns:
        A list of dictionaries representing updates.
    """
    updates: List[Dict[str, str]] = []
    for doc in results:
        abstract = doc.get('abstract')
        # Only include documents with an abstract to avoid empty summaries
        if not abstract:
            continue
        # Determine the agency name from the first agency entry, if available
        agencies = doc.get('agencies', [])
        source = agencies[0]['name'] if agencies else 'Unknown'
        updates.append({
            'date': doc.get('publication_date'),
            'source': source,
            'title': doc.get('title'),
            'link': doc.get('html_url'),
            'content': abstract.strip()
        })
    return updates


def fetch_recent_updates(agencies: List[str], per_page: int = 3) -> List[Dict[str, str]]:
    """Fetch recent documents for multiple agencies and convert them to updates.

    Args:
        agencies: A list of agency slugs to query.
        per_page: Number of documents per agency to retrieve.

    Returns:
        A combined list of update dictionaries.
    """
    all_updates: List[Dict[str, str]] = []
    for slug in agencies:
        try:
            results = fetch_documents_for_agency(slug, per_page=per_page)
            updates = transform_results_to_updates(results)
            all_updates.extend(updates)
        except Exception as exc:
            # Log error in real usage; here we simply skip on failure
            print(f"Warning: failed to fetch documents for {slug}: {exc}")
            continue
    return all_updates