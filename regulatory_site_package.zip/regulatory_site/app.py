"""
Flask application for tracking financial regulatory notices.

This application reads a local JSON data set of recent financial regulatory
notices and displays summaries on a simple web page.  Each entry in the
dataset has a publication date, source agency, title, link to the original
document and a plain‑language description of the change.  At runtime
the application automatically summarizes the text for a concise overview.

The website includes a homepage showing a daily summary for the current
date and a listing page that displays all known notices.  Although this
prototype relies on a static dataset, the architecture could be extended
to periodically fetch new notices from public APIs such as the Federal
Register API and update the dataset accordingly.
"""

from __future__ import annotations

import json
import os
from typing import List, Dict

from flask import Flask, render_template, abort, redirect, url_for, request

# Optional: import stripe for payment integration.  This import is inside a
# try/except block at runtime to avoid raising errors when the stripe module
# is not installed.  The routes that depend on stripe will check for the
# presence of the module and the required environment variables.
try:
    import stripe  # type: ignore
except Exception:
    stripe = None  # type: ignore

from utils import summarise_text, filter_updates_by_date, group_updates_by_date, get_current_date_iso
from federal_register_api import fetch_recent_updates


def load_updates(data_path: str) -> List[Dict[str, str]]:
    """Load regulatory updates from a JSON file.

    Args:
        data_path: Path to the JSON file containing updates.

    Returns:
        A list of dictionaries representing update entries.
    """
    with open(data_path, "r", encoding="utf-8") as f:
        return json.load(f)


# summarise_text, filter_updates_by_date and group_updates_by_date are imported from utils.py


# filter_updates_by_date and group_updates_by_date are imported from utils.py


def create_app() -> Flask:
    """Create and configure the Flask application."""
    app = Flask(__name__, template_folder=os.path.join(os.path.dirname(__file__), "templates"), static_folder=os.path.join(os.path.dirname(__file__), "static"))

    # Load updates from the dataset at startup
    DATA_PATH = os.path.join(os.path.dirname(__file__), "data", "updates.json")
    updates = load_updates(DATA_PATH)

    # Attempt to fetch additional updates from the Federal Register API.  This
    # call will silently fail in environments without internet access.  New
    # documents are appended to the updates list if they are not duplicates.
    def _refresh_updates_from_api():
        """Fetch additional updates from the Federal Register API.

        This helper defines a list of agency slugs representing the financial
        regulators tracked by the site.  It attempts to fetch the most
        recent documents for each agency via the Federal Register API and
        append them to the in‑memory updates list if they are new.  The
        operation is wrapped in a try/except so that network failures or
        missing packages do not crash the application.
        """
        agency_slugs = [
            'federal-deposit-insurance-corporation',      # FDIC
            'federal-reserve-system',                    # Federal Reserve
            'securities-and-exchange-commission',        # SEC
            'foreign-assets-control-office',             # OFAC
            'comptroller-of-the-currency',               # OCC
            'commodity-futures-trading-commission',      # CFTC
            'financial-crimes-enforcement-network'       # FinCEN
        ]
        try:
            api_updates = fetch_recent_updates(agency_slugs, per_page=3)
            if api_updates:
                existing_keys = {(u["title"].lower(), u["date"]) for u in updates}
                for upd in api_updates:
                    key = (upd.get("title", "").lower(), upd.get("date"))
                    if key not in existing_keys:
                        updates.append(upd)
                        existing_keys.add(key)
        except Exception:
            # Ignore any exceptions from network failures
            pass

    # Refresh updates once at startup
    _refresh_updates_from_api()

    @app.route("/")
    def index() -> str:
        """Homepage showing a summary of today's regulatory changes."""
        # Determine today's date in the user's timezone
        today_iso = get_current_date_iso()
        # Filter updates for today
        todays_updates = filter_updates_by_date(updates, today_iso)
        # If no updates for today, show the most recent date available
        if not todays_updates and updates:
            # Sort updates by date descending to find the latest
            latest_date = max(u["date"] for u in updates)
            todays_updates = filter_updates_by_date(updates, latest_date)
            display_date = latest_date
        else:
            display_date = today_iso

        # Compose a single summary for the day by combining all contents
        combined_text = "\n".join(u["content"] for u in todays_updates)
        # Use a longer summary (5 sentences) for the daily overview
        daily_summary = summarise_text(combined_text, sentences=5)

        # Summarise individual entries for display
        entries_with_summary = []
        for u in todays_updates:
            # Provide a slightly longer summary (3 sentences) for individual
            # notices to capture materiality, context and implications.
            entry_summary = summarise_text(u["content"], sentences=3)
            entries_with_summary.append({
                "date": u["date"],
                "source": u["source"],
                "title": u["title"],
                "link": u["link"],
                "summary": entry_summary
            })

        return render_template("index.html", date=display_date, summary=daily_summary, entries=entries_with_summary)

    @app.route("/all")
    def all_updates() -> str:
        """List all updates grouped by date."""
        grouped = group_updates_by_date(updates)
        # Summarise each entry's content for all pages using the same summarisation routine
        # and create a new grouped structure with summaries.
        grouped_summary = {}
        for date, entries in grouped.items():
            summarised_entries = []
            for e in entries:
                # Summarise each notice using a 3‑sentence analyst-grade summary
                try:
                    summary = summarise_text(e.get("content", ""), sentences=3)
                except Exception:
                    summary = e.get("content", "")
                new_entry = dict(e)
                new_entry["summary"] = summary
                summarised_entries.append(new_entry)
            grouped_summary[date] = summarised_entries
        # Sort the dictionary by date descending for display
        sorted_dates = sorted(grouped_summary.keys(), reverse=True)
        grouped_sorted = [(d, grouped_summary[d]) for d in sorted_dates]
        return render_template("all.html", grouped=grouped_sorted)

    # -------------------------------------------------------------------------
    # Payment integration using Stripe.
    #
    # The following routes implement a basic checkout flow for subscription
    # payments using Stripe.  These routes are not linked from the public
    # navigation but provide the infrastructure to enable a paywall in the
    # future.  To activate the checkout, set the STRIPE_API_KEY and
    # STRIPE_PRICE_ID environment variables.  Without these variables or the
    # stripe package installed, attempts to access the payment routes will
    # result in a 500 error.

    @app.route("/subscribe")
    def subscribe() -> str:
        """Render a simple subscription page with a button to start checkout."""
        return render_template("subscribe.html")

    @app.route("/create-checkout-session", methods=["POST"])
    def create_checkout_session():
        """Create a Stripe Checkout session for a subscription.

        Expects that the STRIPE_API_KEY and STRIPE_PRICE_ID environment
        variables are set.  On success, redirects the user to the hosted
        checkout page.  If Stripe is not configured, abort with a 500
        response.
        """
        # Ensure the stripe library and configuration are available
        if stripe is None:
            abort(500, "Stripe library is not installed")
        api_key = os.getenv("STRIPE_API_KEY")
        price_id = os.getenv("STRIPE_PRICE_ID")
        if not api_key or not price_id:
            abort(500, "Stripe API key or price ID not configured")
        stripe.api_key = api_key  # type: ignore
        try:
            checkout_session = stripe.checkout.Session.create(  # type: ignore
                payment_method_types=["card"],
                line_items=[
                    {
                        "price": price_id,
                        "quantity": 1,
                    },
                ],
                mode="subscription",
                success_url=url_for("checkout_success", _external=True) + "?session_id={CHECKOUT_SESSION_ID}",
                cancel_url=url_for("checkout_cancel", _external=True),
            )
            return redirect(checkout_session.url)
        except Exception as e:
            abort(500, f"Error creating checkout session: {e}")

    @app.route("/success")
    def checkout_success():
        """Display a success message after payment completes."""
        return "<h1>Thank you for subscribing!</h1><p>Your payment was successful.</p>"

    @app.route("/cancel")
    def checkout_cancel():
        """Display a message when the checkout is cancelled."""
        return "<h1>Payment cancelled</h1><p>Your subscription was not completed.</p>"

    return app


if __name__ == "__main__":
    # Only run the development server if executed directly
    app = create_app()
    app.run(host="0.0.0.0", port=5000, debug=True)