"""
Utility functions for the regulatory notices project.

This module provides text summarisation and helper functions to
filter and group regulatory updates.  It is separate from the Flask
application so it can be reused in both the dynamic app and the
static site builder without importing Flask.
"""

from __future__ import annotations

import re
import string
from collections import Counter
from datetime import datetime
from typing import List, Dict
from zoneinfo import ZoneInfo

__all__ = [
    "summarise_text",
    "filter_updates_by_date",
    "group_updates_by_date",
    "get_current_date_iso",
]


def summarise_text(text: str, sentences: int = 2) -> str:
    """Generate an analyst‑grade summary of the input text.

    This function attempts to produce a high‑quality summary using the
    OpenAI ChatGPT API (gpt‑4o‑mini).  It provides a detailed system
    message instructing the model to behave like a senior regulatory
    analyst and to craft a summary appropriate for sophisticated legal
    and investment audiences.  The assistant is directed to highlight
    materiality, context and forward‑looking implications rather than
    merely compress the text.  The number of sentences in the summary
    can be adjusted via the ``sentences`` parameter.

    If the OpenAI API is unavailable—because the ``openai`` package is
    missing, no API key is configured, or the network request fails—the
    function falls back to a simple extractive summariser.  This
    fallback splits the text into sentences, scores them based on word
    frequency (excluding common stop words), and returns the top
    ``sentences`` sentences in their original order.  For very short
    inputs the original text is returned unchanged.

    Args:
        text: The input text to summarise.
        sentences: Desired number of sentences in the summary.

    Returns:
        A string containing the summary.
    """
    # Handle empty input
    if not text:
        return ""

    # First try to summarise with the OpenAI API.  This code attempts to
    # import the ``openai`` library and retrieve the API key from the
    # ``OPENAI_API_KEY`` environment variable.  If any step fails, it
    # gracefully falls back to the extractive method defined below.
    try:
        import os
        import openai  # type: ignore
        api_key = os.getenv("OPENAI_API_KEY")
        # Only attempt the API call if a key is present
        if api_key:
            summary_text: str | None = None
            # Build a sophisticated system prompt instructing the model to
            # behave as a senior regulatory analyst.  This prompt encourages
            # identification of materiality, contextualisation of the notice
            # within prior rulemakings and enforcement trends, and
            # forward‑looking commentary.  It also warns against generic
            # phrasing and boilerplate.  The user message requests a
            # summary in a specific number of sentences.
            system_message = (
                "You are a senior regulatory analyst writing for partners at a top-tier "
                "law firm, investment banking compliance leaders, institutional investors "
                "and policy professionals. Assume the reader is highly sophisticated. Do "
                "NOT explain basic regulatory concepts unless absolutely necessary. If a "
                "development is incremental, confirmatory, or largely procedural, state "
                "that explicitly. Your task is not to summarize mechanically, but to "
                "exercise expert judgment. You should identify what matters, explain why "
                "it matters, and place the regulatory development in context. Write with "
                "precision, confidence and analytical depth. Avoid boilerplate, generic "
                "phrasing, or unnecessary background."
            )
            user_message = (
                f"Summarize the following notice in {sentences} sentences. Your summary "
                "must highlight materiality, provide context (e.g., prior rulemakings, "
                "enforcement trends), and include forward-looking implications for "
                "compliance, legal or investment audiences.\n\n"
                f"{text}"
            )
            try:
                # New client interface (openai >= 1.0)
                client = openai.OpenAI(api_key=api_key)
                response = client.chat.completions.create(
                    model="gpt-4o-mini",
                    messages=[
                        {"role": "system", "content": system_message},
                        {"role": "user", "content": user_message},
                    ],
                    max_tokens=600,
                    temperature=0.3,
                )
                summary_text = response.choices[0].message.content.strip()
                print(
                    "[DEBUG] Used OpenAI API for analyst-grade summarization via new client interface."
                )
            except AttributeError:
                # Legacy interface (openai < 1.0)
                openai.api_key = api_key  # type: ignore
                response = openai.ChatCompletion.create(  # type: ignore
                    model="gpt-4o-mini",
                    messages=[
                        {"role": "system", "content": system_message},
                        {"role": "user", "content": user_message},
                    ],
                    max_tokens=600,
                    temperature=0.3,
                )
                summary_text = response.choices[0].message["content"].strip()  # type: ignore
                print(
                    "[DEBUG] Used OpenAI API for analyst-grade summarization via legacy interface."
                )
            # If we successfully obtained a summary, return it
            if summary_text:
                return summary_text
    except Exception as e:
        # Log the exception so we know why the API call failed
        print(f"[DEBUG] Falling back to extractive summarization due to error: {e}")
        # The function will fall back to the extractive approach below.
        pass

    # ---------------------------------------------------------------------
    # Fallback: simple extractive summariser.  It computes word frequencies
    # and selects the top scoring sentences.  If the text is short (less
    # than ``sentences`` sentences or fewer than ~30 words), return as is.
    sentence_delims = re.compile(r'(?:[.!?]+)\s+')
    raw_sentences = sentence_delims.split(text.strip())
    if len(raw_sentences) <= sentences or len(text.split()) < 30:
        return text.strip()
    stop_words = {
        'the', 'and', 'of', 'to', 'in', 'a', 'is', 'it', 'for', 'on', 'that',
        'with', 'as', 'be', 'are', 'this', 'an', 'by', 'or', 'from',
        'at', 'which', 'but', 'not', 'they', 'their', 'its', 'has', 'have',
        'may', 'these', 'will', 'can', 'had', 'been', 'such', 'into', 'about',
        'other', 'more', 'also', 'if', 'all', 'one', 'each', 'any'
    }
    translator = str.maketrans('', '', string.punctuation)
    words = [w.lower().translate(translator) for w in text.split()]
    freq = Counter()
    for w in words:
        if w and w not in stop_words and not w.isdigit():
            freq[w] += 1
    sentence_scores = []
    for i, sent in enumerate(raw_sentences):
        sent_words = [w.lower().translate(translator) for w in sent.split()]
        score = sum(freq.get(w, 0) for w in sent_words if w and w not in stop_words)
        sentence_scores.append((i, score, sent.strip()))
    top_sentences = sorted(sentence_scores, key=lambda x: x[1], reverse=True)[:sentences]
    selected = sorted(top_sentences, key=lambda x: x[0])
    summary = ' '.join(s[2] for s in selected)
    return summary


def filter_updates_by_date(updates: List[Dict[str, str]], date_str: str) -> List[Dict[str, str]]:
    """Filter updates for a given ISO date string."""
    return [u for u in updates if u.get("date") == date_str]


def group_updates_by_date(updates: List[Dict[str, str]]) -> Dict[str, List[Dict[str, str]]]:
    """Group updates by their publication date."""
    grouped: Dict[str, List[Dict[str, str]]] = {}
    for u in updates:
        d = u.get("date")
        if d:
            grouped.setdefault(d, []).append(u)
    return grouped


def get_current_date_iso() -> str:
    """Return today's date in America/New_York timezone as an ISO string."""
    tz = ZoneInfo("America/New_York")
    return datetime.now(tz=tz).date().isoformat()